package com.example.susong.testmvp.util.exception;

public class BaseException extends Throwable {
    public BaseException(String message) {
        super(message);
    }
}
