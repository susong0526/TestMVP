package com.example.susong.testmvp.framework;

public interface Listener {
    void showError(String url, int code, String message);
}
