package com.example.susong.testmvp.base.fragment;

import android.os.Bundle;

public interface OnFragmentResultListener {
    void onFragmentResult(int requestCode, int resultCode, Bundle data);
}
