package com.example.susong.testmvp.entity.dto.response;

/**
 *  生成响应数据JSON数据
 */
public class ResponseLogObj {
    private String url;
    private String data;

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }
}
