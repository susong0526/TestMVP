package com.example.susong.testmvp.database;

public interface Specification {
    String toSqlQuery();
}
