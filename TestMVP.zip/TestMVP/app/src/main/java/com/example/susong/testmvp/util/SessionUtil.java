package com.example.susong.testmvp.util;

/**
 * 会话数据相关功能
 */
public class SessionUtil {

    /**
     * 退出登录
     */
    public static void loginOut() {
    }

    /**
     * 是否已经登录,请统一使用该方法判断用户是否已经登录
     */
    public static boolean isLogin() {
        return false;
    }
}
