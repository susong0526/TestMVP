package com.example.susong.testmvp.entity.domain.eventbus;

import java.io.Serializable;

/**
 *  EventBus基础事件对象,所有事件类的基类
 *  @author scott
 */
public class EventObj implements Serializable {
}
