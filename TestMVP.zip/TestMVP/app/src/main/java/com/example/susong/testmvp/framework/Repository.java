package com.example.susong.testmvp.framework;

public interface Repository {
    void finish();
}
