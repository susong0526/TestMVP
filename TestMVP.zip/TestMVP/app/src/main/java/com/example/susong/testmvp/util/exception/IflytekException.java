package com.example.susong.testmvp.util.exception;


/**
 *  科大讯飞异常
 */
public class IflytekException extends BaseException {
    public IflytekException(String message) {
        super(message);
    }
}
