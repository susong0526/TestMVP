package com.example.susong.testmvp.http;

/**
 * 请求URL
 */
public class HttpDataReqUrl {
    /** 获取我的钱包及银行卡列表 */
    public static final String URL_GET_PURSE_BANKCARD = "v1.0/userwallet/getMyWalletAndBankCard";
    /** 计算提现金额 */
    public static final String URL_CALCULATE_WITHDRAW_MONTY = "v1.0/userwallet/calcWithdrawals";
}
